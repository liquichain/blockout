defmodule EthereumJSONRPC.TransactionsTest do
  use ExUnit.Case, async: true

  doctest EthereumJSONRPC.Transactions
end
