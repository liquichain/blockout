defmodule EthereumJSONRPC.LogTest do
  use ExUnit.Case, async: true

  doctest EthereumJSONRPC.Log
end
