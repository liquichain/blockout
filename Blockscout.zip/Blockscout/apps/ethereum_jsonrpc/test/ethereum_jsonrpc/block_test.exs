defmodule EthereumJSONRPC.BlockTest do
  use ExUnit.Case, async: true

  doctest EthereumJSONRPC.Block
end
