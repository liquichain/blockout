defmodule BlockScoutWeb.AddressTokenTransferView do
  use BlockScoutWeb, :view
end
