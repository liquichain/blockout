defmodule BlockScoutWeb.AddressContractVerificationView do
  use BlockScoutWeb, :view
end
