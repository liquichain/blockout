defmodule BlockScoutWeb.TransactionTokenTransferView do
  use BlockScoutWeb, :view
end
