defmodule Explorer.Chain.DataTest do
  use ExUnit.Case, async: true

  doctest Explorer.Chain.Data
end
