defmodule Explorer.Chain.HashTest do
  use ExUnit.Case, async: true

  doctest Explorer.Chain.Hash
end
