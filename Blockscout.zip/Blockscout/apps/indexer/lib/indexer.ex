defmodule Indexer do
  @moduledoc """
  Indexes an Ethereum-based chain using JSONRPC.
  """
end
