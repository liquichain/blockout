#!/bin/sh

release_ctl eval --mfa "Explorer.ReleaseTasks.seed/1" --argv -- "$@"
